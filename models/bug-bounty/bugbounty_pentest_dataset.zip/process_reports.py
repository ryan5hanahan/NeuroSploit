import os
import json
import re

def extract_sections(content):
    sections = {}
    # Tenta extrair o título
    title_match = re.search(r'^# (.*)', content)
    if title_match:
        sections['title'] = title_match.group(1).strip()
    
    # Extrai o resumo/vulnerabilidade
    summary_match = re.search(r'## Summary:(.*?)##', content, re.DOTALL | re.IGNORECASE)
    if summary_match:
        sections['summary'] = summary_match.group(1).strip()
    
    # Extrai passos para reproduzir
    steps_match = re.search(r'## Steps To Reproduce:(.*?)##', content, re.DOTALL | re.IGNORECASE)
    if not steps_match:
        steps_match = re.search(r'## Steps:(.*?)##', content, re.DOTALL | re.IGNORECASE)
    if steps_match:
        sections['steps'] = steps_match.group(1).strip()
        
    # Extrai impacto
    impact_match = re.search(r'## Impact(.*?)##', content, re.DOTALL | re.IGNORECASE)
    if not impact_match:
        impact_match = re.search(r'## Impact(.*)', content, re.DOTALL | re.IGNORECASE)
    if impact_match:
        sections['impact'] = impact_match.group(1).strip()

    return sections

def create_dataset(reports_dir):
    dataset = []
    files = [f for f in os.listdir(reports_dir) if f.endswith('.md')]
    
    for filename in files:
        filepath = os.path.join(reports_dir, filename)
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                
            sections = extract_sections(content)
            
            if 'title' in sections and ('summary' in sections or 'steps' in sections):
                # Formato Alpaca: instruction, input, output
                instruction = f"Explique a vulnerabilidade e como reproduzi-la baseando-se no relatório: {sections.get('title')}"
                
                output = ""
                if 'summary' in sections:
                    output += f"### Resumo da Vulnerabilidade\n{sections['summary']}\n\n"
                if 'steps' in sections:
                    output += f"### Passos para Reproduzir\n{sections['steps']}\n\n"
                if 'impact' in sections:
                    output += f"### Impacto\n{sections['impact']}\n"
                
                dataset.append({
                    "instruction": instruction,
                    "input": "",
                    "output": output.strip()
                })
        except Exception as e:
            continue
            
    return dataset

if __name__ == "__main__":
    reports_path = "/home/ubuntu/bugbounty-reports/reports"
    print(f"Processando relatórios em {reports_path}...")
    ds = create_dataset(reports_path)
    print(f"Total de exemplos gerados: {len(ds)}")
    
    with open("/home/ubuntu/bugbounty_finetuning_dataset.json", "w", encoding="utf-8") as f:
        json.dump(ds, f, indent=4, ensure_ascii=False)
    print("Dataset salvo em /home/ubuntu/bugbounty_finetuning_dataset.json")
