# Guia de Fine-Tuning para o Agente de Pentest (NeuroSploit Plus)

Este guia descreve como utilizar o dataset gerado a partir de relatórios reais de bug bounty para treinar um modelo de linguagem (LLM) e integrá-lo como uma base de conhecimento adicional para o seu agente de pentest **NeuroSploit**.

## 1. O Dataset
O dataset foi extraído de quase 10.000 relatórios reais. Ele contém pares de instrução/resposta focados em:
- Identificação de vulnerabilidades.
- Passos detalhados para reprodução (PoC).
- Análise técnica de impacto.

Arquivos gerados:
- `bugbounty_finetuning_dataset.json`: Formato Alpaca (Instruction, Input, Output).
- `bugbounty_chat_finetuning.jsonl`: Formato Chat (System, User, Assistant) pronto para frameworks modernos.

## 2. Opções de Treinamento

### Opção A: Unsloth (Recomendado para iniciantes/GPUs locais)
O Unsloth é 2x mais rápido e usa 70% menos memória.
```python
from unsloth import FastLanguageModel
import torch
from trl import SFTTrainer
from transformers import TrainingArguments

# Configuração do modelo (ex: Llama-3-8B ou Mistral-v0.3)
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name = "unsloth/llama-3-8b-bnb-4bit",
    max_seq_length = 2048,
    load_in_4bit = True,
)

# Adicionar LoRA adapters
model = FastLanguageModel.get_peft_model(
    model,
    r = 16,
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj"],
    lora_alpha = 16,
    lora_dropout = 0,
)

# Treinamento
trainer = SFTTrainer(
    model = model,
    train_dataset = dataset, # Carregar o JSON gerado
    dataset_text_field = "text",
    max_seq_length = 2048,
    args = TrainingArguments(
        per_device_train_batch_size = 2,
        gradient_accumulation_steps = 4,
        warmup_steps = 5,
        max_steps = 60,
        learning_rate = 2e-4,
        fp16 = not torch.cuda.is_bf16_supported(),
        bf16 = torch.cuda.is_bf16_supported(),
        logging_steps = 1,
        output_dir = "outputs",
    ),
)
trainer.train()
```

### Opção B: OpenAI Fine-tuning (API)
Se você preferir usar o GPT-4o-mini ou GPT-3.5-turbo:
1. Faça o upload do arquivo `bugbounty_chat_finetuning.jsonl` no dashboard da OpenAI.
2. Inicie um job de Fine-tuning selecionando o arquivo.

## 3. Integração com NeuroSploit

Para usar o modelo treinado como um "Plus" no NeuroSploit:

1. **Custom Agent**: Crie um novo agente na pasta `custom_agents/` do NeuroSploit que aponte para o seu modelo treinado.
2. **Prompt Injection**: Atualize o arquivo `prompts/library.json` para incluir referências ao conhecimento extraído.
3. **RAG (Opcional)**: Se não quiser fazer fine-tuning completo, você pode usar os arquivos MD originais em um banco de dados vetorial (Vector DB) e conectar ao NeuroSploit via uma ferramenta de busca.

## 4. Próximos Passos
- Teste o modelo com casos de uso específicos (ex: "Como explorar um IDOR em APIs GraphQL?").
- Verifique se o modelo retém a capacidade de seguir as ferramentas do NeuroSploit enquanto aplica o conhecimento dos relatórios.
