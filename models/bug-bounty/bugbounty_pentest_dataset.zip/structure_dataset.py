import json

def convert_to_chat_format(input_file, output_file):
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    chat_dataset = []
    system_prompt = (
        "Você é um assistente de inteligência artificial especializado em segurança ofensiva e pentest. "
        "Seu objetivo é ajudar pesquisadores de segurança a entender vulnerabilidades reais, "
        "fornecendo resumos técnicos, passos de reprodução e análises de impacto baseadas em relatórios reais de bug bounty."
    )
    
    for item in data:
        chat_item = {
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": item["instruction"]},
                {"role": "assistant", "content": item["output"]}
            ]
        }
        chat_dataset.append(chat_item)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        for entry in chat_dataset:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

if __name__ == "__main__":
    convert_to_chat_format(
        "/home/ubuntu/bugbounty_finetuning_dataset.json",
        "/home/ubuntu/bugbounty_chat_finetuning.jsonl"
    )
    print("Dataset estruturado em formato JSONL para fine-tuning salvo em /home/ubuntu/bugbounty_chat_finetuning.jsonl")
